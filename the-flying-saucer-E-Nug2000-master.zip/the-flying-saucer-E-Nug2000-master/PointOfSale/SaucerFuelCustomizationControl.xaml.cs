﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TheFlyingSaucer.Data.Drinks;

namespace PointOfSale
{
    /// <summary>
    /// Interaction logic for SaucerFuelCustomizationControl.xaml
    /// </summary>
    public partial class SaucerFuelCustomizationControl : UserControl
    {
        public SaucerFuelCustomizationControl()
        {
            InitializeComponent();
            this.DataContext = new SaucerFuel();
        }
        private void GoBack(object sender, RoutedEventArgs e)
        {
            itemContainer.Child = new MenuSelectionControl();
        }

        private void MarkCream(object sender, RoutedEventArgs e)
        {

        }

        private void MarkDecaf(object sender, RoutedEventArgs e)
        {

        }
    }
}
