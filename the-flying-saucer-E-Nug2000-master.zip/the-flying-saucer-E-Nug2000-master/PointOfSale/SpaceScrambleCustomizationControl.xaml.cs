﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TheFlyingSaucer.Data.Entrees;

namespace PointOfSale
{
    /// <summary>
    /// Interaction logic for SpaceScrambleCustomizationControl.xaml
    /// </summary>
    public partial class SpaceScrambleCustomizationControl : UserControl
    {
        public SpaceScrambleCustomizationControl()
        {
            InitializeComponent();
            this.DataContext = new SpaceScramble();
        }

        private void HoldPeppers(object sender, RoutedEventArgs e)
        {

        }

        private void HoldSourCream(object sender, RoutedEventArgs e)
        {

        }

        private void HoldCheese(object sender, RoutedEventArgs e)
        {

        }

        private void HoldPotatoes(object sender, RoutedEventArgs e)
        {

        }

        private void HoldSausage(object sender, RoutedEventArgs e)
        {

        }


        private void GoBack(object sender, RoutedEventArgs e)
        {
            itemContainer.Child = new MenuSelectionControl();
        }

    }
}
