﻿using System;
using System.Collections.Generic;
using System.Text;
using TheFlyingSaucer.Data;
using TheFlyingSaucer.Data.Drinks;
using TheFlyingSaucer.Data.Entrees;
using TheFlyingSaucer.Data.Sides;
using Xunit;
using System.ComponentModel;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Collections;
using PointOfSale;


namespace TheFlyingSaucer.DataTests
{
    /// <summary>
    /// unit testing for the cash view model class
    /// </summary>
    public class CashViewModelTests
    {

        /*
        [Theory]
        public void CanChangeDrawerProperty(string property)
        {

            CashViewModel cvm = new CashViewModel();
            cvm.TotalAmount
            cvm.
            Order ord = new Order();
            TestOrderItem mo = new TestOrderItem();
            ord.Add(mo);
            
            
        }*/

    }
}
